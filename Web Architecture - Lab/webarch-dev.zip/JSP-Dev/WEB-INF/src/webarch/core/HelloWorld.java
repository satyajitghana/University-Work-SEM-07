package webarch.core;

public class HelloWorld {
    public String sayHello() {
        return "Hello from JSP !";
    }
}
