package com.example.college.webarchlab.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.example.college.webarchlab.database.Queries;
import com.example.college.webarchlab.model.Product;

public class SearchServlet extends HttpServlet {
    private static final long serialVersionUID = 1;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String searchInput = request.getParameter("name");

        List<Product> products;
        try {
            products = Queries.findProduct(searchInput);
        } catch (SQLException e) {
            e.printStackTrace();
            products = new ArrayList<Product>();
        }

        // putting the list of products obtained as an attribute using setAttribute method
        // so that the data can be accessed in the jsp file via code
        request.setAttribute("products", products);

        RequestDispatcher dispatcher = request.getRequestDispatcher("home.jsp");
        dispatcher.include(request, response);
    }
}
