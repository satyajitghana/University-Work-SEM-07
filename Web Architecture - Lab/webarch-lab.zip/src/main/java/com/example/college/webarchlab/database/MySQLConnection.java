package com.example.college.webarchlab.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class MySQLConnection {
    private static Connection conn;

    public static Connection getConnection() {
        if (conn == null) {
            try {
                // no need for the Class.forName("com.mysql.jdbc.Driver") line
                // since that driver is deprecated in mysql-connector-java 8.0.23
                // now it uses com.mysql.cj.jdbc.Driver which doesnt need that line
                // since the driver is automatically registered.
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/college", "spring", "12345");
                initTables();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return conn;
    }

    public static void initTables() throws SQLException {
        createUserTable();
        createProductTable();
    }

    public static void createUserTable() throws SQLException {
        Statement statement = conn.createStatement();

        statement.executeUpdate(
            "CREATE TABLE IF NOT EXISTS user("
        +   "   id INTEGER PRIMARY KEY NOT NULL,"
        +   "   name VARCHAR(30),"
        +   "   email VARCHAR(30),"
        +   "   password VARCHAR(30)"
        +   ");"
        );
    }

    public static void createProductTable() throws SQLException {
        Statement statement = conn.createStatement();

        statement.executeUpdate(
            "CREATE TABLE IF NOT EXISTS product("
        +   "   id INTEGER PRIMARY KEY NOT NULL,"
        +   "   name VARCHAR(30),"
        +   "   description VARCHAR(100),"
        +   "   price FLOAT"
        +   ");"
        );
    }
}
