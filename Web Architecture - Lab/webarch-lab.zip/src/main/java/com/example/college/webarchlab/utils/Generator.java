package com.example.college.webarchlab.utils;

import java.util.concurrent.ThreadLocalRandom;

public class Generator {
    public static int generateId() {
        return ThreadLocalRandom.current().nextInt(0, 99999);
    }
}
