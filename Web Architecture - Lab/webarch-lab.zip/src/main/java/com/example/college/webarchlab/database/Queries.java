package com.example.college.webarchlab.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.example.college.webarchlab.model.Product;
import com.example.college.webarchlab.utils.Generator;

public class Queries {
    public static String getPasswordOfUser(String email) throws SQLException {
        Connection conn = MySQLConnection.getConnection();

        PreparedStatement statement = conn.prepareStatement("SELECT password FROM user WHERE email = ?");
        statement.setString(1, email);

        ResultSet res = statement.executeQuery();
        if (! res.next())
            return null;
        return res.getString(1);
    }

    public static void addUser(String name, String email, String password) throws SQLException {
        Connection conn = MySQLConnection.getConnection();

        PreparedStatement statement = conn.prepareStatement("INSERT INTO user VALUES(?, ?, ?, ?);");
        
        statement.setInt(1, Generator.generateId());
        statement.setString(2, name);
        statement.setString(3, email);
        statement.setString(4, password);
        
        statement.executeUpdate();
    }

    public static List<Product> findProduct(String name) throws SQLException {
        Connection conn = MySQLConnection.getConnection();

        PreparedStatement statement = conn.prepareStatement("SELECT * FROM product WHERE name LIKE ?");
        statement.setString(1, name + "%");
        ResultSet res = statement.executeQuery();
        
        List<Product> products = new ArrayList<Product>();

        while (res.next())
            products.add(new Product(res.getString(2), res.getString(3), res.getFloat(4)));
        
        return products;
    }
}
