package com.example.college.webarchlab.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.example.college.webarchlab.database.Queries;

public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String retrievedPassword = null;
        
        try {
            retrievedPassword = Queries.getPasswordOfUser(email);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (retrievedPassword == null || ! retrievedPassword.equals(password)) {
            RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");

            // setting flag using setAttribute method so that the flag can be accessed in
            // the jsp file
            request.setAttribute("invalidUsernameOrPassword", true);
            
            dispatcher.include(request, response);
        }
        else {
            response.sendRedirect(request.getContextPath() + "/home.jsp");
        }
    }
}
