# Web arch lab

## Setup

Make sure you have jdk 11 and MySQL installed. In `MySQLConnection.java` class, update the `DriverManager.getConnection` line to add the correct mysql database, username and password that corresponds to your installation of MySQL.

To run the program on linux, run

```
$ ./mvnw tomcat7:run
```

or on windows,

```
$ ./mvnw.cmd tomcat7:run
```

urls:
- login page: `http://localhost:8080/webarchlab/login.jsp`
- register page: `http://localhost:8080/webarchlab/register.jsp`
- home page: `http://localhost:8080/webarchlab/home.jsp`
